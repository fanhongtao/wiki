1. Modify Tomcat conf/server.xml, add URIEncoding

    <Connector port="18080" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443" URIEncoding="UTF-8"/>

2. To start tomcat:
2.1. Entry apache-tomcat-6.0.18/bin
2.2. Execute cmd:   
      source env.cshrc
2.3. Execute cmd:
      ./startup.sh


3. To stop tomcat:
3.1. Entry apache-tomcat-6.0.18/bin
3.2. Execute cmd:   
      source env.cshrc
3.3. Execute cmd:
      ./shutdown.sh


4. Content of env.cshrc
	setenv JAVA_HOME /opt/jdk1.5.0_17/bin
	setenv JRE_HOME /opt/jdk1.5.0_17/jre
	setenv PATH ${JAVA_HOME}:$PATH



5. Add crontab
    0 17 * * * ${HOME}/wiki/tar_wiki.sh
