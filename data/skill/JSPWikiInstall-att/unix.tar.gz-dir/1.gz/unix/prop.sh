#!/bin/ksh

echo "input App Name(eg, Huawei):"
read appname

echo "input Wiki Name(eg, huawei):"
read wikiname

echo "input Wiki Path(eg, /home/wiki):"
read wikipath

echo "input Wiki URL(eg, http://10.168.67.113:18080):"
read wikiurl


propname="wiki.${wikiname}.properties"
cp wiki.template.properties ${propname}

cat ${propname} | sed "s#%appname%#${appname}#"   > ${propname}
cat ${propname} | sed "s#%wikiname%#${wikiname}#" > ${propname}
cat ${propname} | sed "s#%wikipath%#${wikipath}#" > ${propname}
cat ${propname} | sed "s#%wikiurl%#${wikiurl}#"   > ${propname}

