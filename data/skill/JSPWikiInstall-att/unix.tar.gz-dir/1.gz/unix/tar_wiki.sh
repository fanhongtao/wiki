#!/bin/ksh

cd /home2/fht/wiki
rm -rf localhost
cp -r ~/apache-tomcat-6.0.18/conf/Catalina/localhost .
curr_date=`date +"%Y-%m-%d"`
tar_file="wiki.data.${curr_date}.tar"
tar cvf $tar_file data localhost cfg unix
gzip $tar_file
if [ ! -d bak ]; then
    mkdir bak
fi
mv ${tar_file}.gz bak

